library(testthat)
library(reval)

test_check("reval")
